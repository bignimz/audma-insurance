# Insurance Business Website

This is a website designed for an Insurance Company. The website is responsive and adapts well to any mobile device.

## Design Preview

## Technologies Used

Technologies used to develop this website include:
1. HTML5 
2. CSS3
3. BOOTSTRAP5
4. VANILLA JAVASCRIPT
5. JQUERY
6. MARKDOWN


